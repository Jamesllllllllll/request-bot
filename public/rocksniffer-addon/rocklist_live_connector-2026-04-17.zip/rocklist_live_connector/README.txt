RockList.Live Connector for RockSniffer

What this addon does
- Watches RockSniffer for song starts.
- Sends the current song to RockList.Live.
- Asks RockList.Live to set the matching queued song as current.

How to install it
1. Copy the rocklist_live_connector folder into RockSniffer's addons folder.
2. Open rocklist_live_connector.html.
3. Paste the relay URL from RockList.Live and save it.
4. Keep the page open in a browser tab or OBS browser source while you play.

What to expect
- The first release only sets the current song.
- It does not automatically mark songs as played.
- If more than one queued song matches, RockList.Live leaves the queue unchanged.
